# EasyInstallerV2

## Want to help cover egress and storage costs? Consider donating [here!](https://paypal.me/blksservers?country.x=US&locale.x=en_US)

## Download [here](https://github.com/simplyblk/EasyInstallerV2/releases)!

### If the application doesn't open, [download .net runtime here.](https://dotnet.microsoft.com/en-us/download/dotnet/thank-you/runtime-6.0.16-windows-x64-installer)

Credits to [Ender](https://github.com/Ender-0001/) for writing the code, [Kyiro's EasyInstaller](https://github.com/Kyiro/Fortnite-ManifestsArchive) for inspiration on design, and [blk](https://github.com/simplyblk) for providing and maintaing servers.  

![243219350-18766d62-9b56-4cd5-aeac-8dac3172075d](https://github.com/simplyblk/EasyInstallerV2/assets/59186634/e21cac92-7936-4713-a876-6b0f0797c972)

If you wish to use this somewhere or contribute to add a build, DM me @ blk#6964, or send me an Email @ FortniteBuildsArchive@gmail.com
